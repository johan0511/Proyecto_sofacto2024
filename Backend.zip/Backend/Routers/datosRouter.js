const express = require("express");
const router = express.Router();
const datosController = require("../Controllers/datosController");

router.get("/Proveedor", datosController.obtenerProveedores);
router.get("/Proveedor/:id", datosController.obtenerProveedorPorId);
router.post("/Proveedor", datosController.crearProveedor);
router.put("/Proveedor/:id", datosController.actualizarProveedor);
router.delete("/Proveedor/:id", datosController.eliminarProveedor);

module.exports = router;
